"""
基础功能测试
"""

import pytest
from py_microservice_sdk.context import create_context, get_trace_id
from py_microservice_sdk.logger import get_logger
from py_microservice_sdk.http_client import create_response, OK


def test_context_creation():
    """测试上下文创建"""
    ctx = create_context()
    assert ctx is not None
    assert ctx.trace_id is not None
    assert len(ctx.trace_id) > 0


def test_trace_id_generation():
    """测试 TraceID 生成"""
    ctx1 = create_context()
    ctx2 = create_context()
    
    # 每次生成的 TraceID 应该不同
    assert ctx1.trace_id != ctx2.trace_id


def test_logger_creation():
    """测试日志器创建"""
    logger = get_logger("test-service")
    assert logger is not None


def test_response_creation():
    """测试响应创建"""
    ctx = create_context()
    response = create_response(
        context=ctx,
        code=OK,
        data={"message": "test"}
    )
    
    assert response is not None
    assert response.code == OK.code
    assert response.data["message"] == "test"
    assert response.trace_id == ctx.trace_id


if __name__ == "__main__":
    pytest.main([__file__]) 
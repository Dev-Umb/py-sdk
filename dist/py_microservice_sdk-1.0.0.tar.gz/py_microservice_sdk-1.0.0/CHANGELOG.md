# 变更日志

本文档记录了项目的所有重要变更。

格式基于 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.0.0/)，
并且遵循 [语义化版本](https://semver.org/lang/zh-CN/)。

## [1.0.0] - 2025-07-05

### 新增
- 🎉 首次发布 Python 微服务通用 SDK
- ✨ 上下文管理模块 - 基于 contextvars 的异步安全 TraceID 传递
- ✨ 日志管理模块 - 统一日志格式，支持火山引擎 TLS
- ✨ HTTP 客户端模块 - 标准化 API 响应格式和请求处理
- ✨ Nacos 集成模块 - 配置管理和服务注册发现
- 📚 完整的文档和示例代码
- 🔧 支持多种 Web 框架（FastAPI、Flask、Django、Tornado）
- 🌐 支持环境变量配置
- 🧪 完整的测试用例

### 特性
- 零配置启动，所有配置通过 Nacos 自动获取
- 自动包含 TraceID 的结构化日志
- 标准化的 HTTP 请求和响应处理
- 自动 TraceID 传递，支持异步安全
- 基于 Nacos 的服务注册与发现
- 完整的链路追踪和日志聚合

### 依赖
- Python >= 3.8
- requests >= 2.32.4
- urllib3 >= 1.26.20, < 3.0.0
- contextvars >= 2.4

### 可选依赖
- 火山引擎 TLS 支持: volcengine >= 1.0.184, lz4 >= 4.0.0
- Web 框架支持: fastapi, flask, django, tornado
- 环境变量支持: python-dotenv >= 0.19.0

---

## [Unreleased]

### 计划新增
- 更多的中间件支持
- 性能监控和指标收集
- 分布式追踪增强
- 更多的日志输出格式
- 配置热重载优化 
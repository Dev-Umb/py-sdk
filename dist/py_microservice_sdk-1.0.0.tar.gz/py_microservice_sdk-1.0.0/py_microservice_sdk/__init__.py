"""
Python 微服务通用 SDK

一个为 Python 微服务开发设计的通用工具包，提供统一的日志管理、HTTP 客户端、上下文管理和服务注册发现等功能。

主要模块：
- context: 上下文管理和 TraceID 传递
- logger: 统一日志管理，支持火山引擎 TLS
- http_client: 标准化 HTTP 客户端和响应处理
- nacos: 基于 Nacos 的配置管理和服务注册发现

快速开始：
    >>> from py_microservice_sdk.context import create_context
    >>> from py_microservice_sdk.logger import get_logger
    >>> 
    >>> ctx = create_context()
    >>> logger = get_logger("my-service")
    >>> logger.info(ctx, "服务启动成功")
"""

# 版本信息
__version__ = "1.0.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

# 导入主要的公共API
from .context import (
    Context,
    create_context,
    get_current_context,
    set_context,
    get_trace_id,
    create_context_from_request,
    create_context_from_grpc
)

from .logger import (
    get_logger,
    SDKLogger,
    init_logger_manager
)

from .http_client import (
    APIResponse,
    ResponseBuilder,
    create_response,
    BusinessCode,
    OK,
    INTERNAL_SERVER_ERROR,
    ROOM_NOT_FOUND,
    UNAUTHORIZED,
    INVALID_PARAMS,
    HttpClient,
    create_fastapi_middleware,
    create_flask_middleware,
    create_django_middleware
)

from .nacos import (
    registerNacos,
    unregisterNacos,
    init_nacos_client,
    init_service_manager,
    register_service,
    unregister_service,
    register_services_from_config,
    cleanup,
    get_config
)

# 公共API列表
__all__ = [
    # 版本信息
    "__version__",
    "__author__",
    "__email__",
    
    # 上下文管理
    "Context",
    "create_context",
    "get_current_context", 
    "set_context",
    "get_trace_id",
    "create_context_from_request",
    "create_context_from_grpc",
    
    # 日志管理
    "get_logger",
    "SDKLogger",
    "init_logger_manager",
    
    # HTTP 客户端
    "APIResponse",
    "ResponseBuilder", 
    "create_response",
    "BusinessCode",
    "OK",
    "INTERNAL_SERVER_ERROR",
    "ROOM_NOT_FOUND",
    "UNAUTHORIZED",
    "INVALID_PARAMS",
    "HttpClient",
    "create_fastapi_middleware",
    "create_flask_middleware",
    "create_django_middleware",
    
    # Nacos 服务
    "registerNacos",
    "unregisterNacos",
    "init_nacos_client",
    "init_service_manager",
    "register_service", 
    "unregister_service",
    "register_services_from_config",
    "cleanup",
    "get_config"
] 